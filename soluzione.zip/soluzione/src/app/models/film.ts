export interface Film {
  id: number,
  poster_path: string,
  isFavorite: boolean,
  favoriteId?: number,
}
