import { Component, OnInit } from '@angular/core';
import { AuthService } from './auth/auth.service';

@Component({
  selector: 'app-navbar',
  template: `
   <nav class="navbar navbar-expand navbar-dark bg-dark">
  <a class="navbar-brand">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" [routerLink]="['/']" routerLinkActive="active" >Film</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" [routerLink]="['/profilo']" routerLinkActive="active">Profilo</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" (click)="logout()" [routerLink]="['/login']" routerLinkActive="active">Logout</a>
      </li>
    </ul>
  </div>
</nav>
  `,
  styles: [
  ]
})
export class NavbarComponent implements OnInit {

  constructor(private authSrv: AuthService) { }

  ngOnInit(): void {
  }

  logout(){
    this.authSrv.logout();
  }

}
