import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../auth.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  constructor(private authSrv: AuthService, private router: Router) { }

  ngOnInit(): void {

  }

  async onsubmit(form: NgForm) {
    console.log(form.value);
      await this.authSrv.registration(form.value).toPromise();
      form.reset();
      alert('Nuovo User registrato correttamente!');
      this.router.navigate(['/login']);
  }

}
