import { Component, Input, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Film } from 'src/app/models/film';
import { FilmService } from 'src/app/service/film.service';
import { AuthData, AuthService } from 'src/app/auth/auth.service';
import { HttpClient } from '@angular/common/http';
import { Favoriti } from 'src/app/models/favoriti';
import { take, map } from 'rxjs/operators';

@Component({
  selector: 'app-film-card',
  templateUrl: './film-card.component.html',
  styleUrls: ['./film-card.component.scss']
})
export class FilmCardComponent implements OnInit {
  @Input() film!: Film

  films!: Film[];
  sub!: Subscription
  utenteLoggato!: AuthData | null
  utenteId: number | undefined
  baseUrl = 'http://localhost:4201/api'
  // fav: boolean = false

  constructor(private filmSrv: FilmService, private authSrv: AuthService, private http: HttpClient) { }


  ngOnInit():void {
    this.authSrv.user$.subscribe((user)=>{
      this.utenteLoggato = user;
      this.utenteId = user?.user.id
    })

    console.log(this.film.id)
    //  this.sub = this.filmSrv.caricaPreferiti(this.utenteId).subscribe(bho=>{
    //    this.favoriti = bho
    //    console.log(this.favoriti)
    //  })


  }

 async preferito(movieId: number, userId: number){
    console.log(this.utenteLoggato)
   this.filmSrv.aggiungiPreferito(movieId,userId).subscribe(
    (newFavorite:Favoriti) => {
     this.film.isFavorite = true;
     this.film.favoriteId = newFavorite.id;
   })
  }

  async rimuovi(id?: number){
    if(!id) {
      return;
    }
    this.filmSrv.removeFavorites(id).subscribe({
      next: () => {
        this.film.isFavorite = false;
      }
    })
  }

  public get isFavorite():boolean {
    return this.film.isFavorite;
  }

}
