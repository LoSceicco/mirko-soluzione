import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Film } from 'src/app/models/film';
import { FilmService } from 'src/app/service/film.service';
import { AuthData, AuthService } from 'src/app/auth/auth.service';
import { Favoriti } from 'src/app/models/favoriti';
import { map, mergeMap, switchMap, tap } from 'rxjs/operators';

@Component({
  selector: 'app-film',
  templateUrl: './film.component.html',
  styleUrls: ['./film.component.scss']
})
export class FilmComponent implements OnInit {
  films!: Film[];
  sub!: Subscription
  utenteLoggato!: AuthData | null
  utenteId: number | undefined
  favoriti!: Favoriti[]

  constructor(private filmSrv: FilmService, private authSrv: AuthService) { }
  ngOnInit(): void {
    // versione con subscribe
    // this.sub = this.authSrv.user$.subscribe(
    //   (user) => {
    //     this.utenteLoggato = user;
    //     this.utenteId = user?.user.id;

    //     this.filmSrv.caricaPreferiti(this.utenteId).subscribe(
    //       (favorites:Favoriti[]) => {
    //         this.filmSrv.caricaFilm().subscribe(
    //           (film:Film[]) => {
    //             this.films = this.manageFavorites(film, favorites);
    //           }
    //         )
    //       }
    //     )
    //   }
    // )

    // versione con rxjs
    this.sub = this.authSrv.user$.pipe(
      tap((user) => {
        this.utenteLoggato = user;
        this.utenteId = user?.user.id
      }),
      switchMap((user) => {
        return this.filmSrv.caricaFilm()
      }),
      mergeMap(
        (film:Film[]) => {
          return this.filmSrv.caricaPreferiti(this.utenteId)
            .pipe(map(
              (favorites:Favoriti[]) => {
                return {
                  movies: film,
                  favorites,
                }
              }
            ))
        }
      )
    )
    .subscribe((data: { movies:Film[], favorites:Favoriti[] }) => {
      this.films = this.manageFavorites(data.movies, data.favorites);
    })

    // this.authSrv.user$.subscribe((user)=>{
    //   this.utenteLoggato = user;
    //   this.utenteId = user?.user.id
    // })

    // this.sub = this.filmSrv.caricaPreferiti(this.utenteId).subscribe(bho=>{
    //   this.favoriti = bho
    //   console.log(this.favoriti)
    // })
  }

  manageFavorites(film:Film[], favorites:Favoriti[]): Film[] {
    return film.map(f => {
      const favorite = favorites.find(fav => fav.movieId === f.id);
      if (favorite) {
        f.isFavorite = true;
        f.favoriteId = favorite.id;
      }
      return f;
    })
  }


}
