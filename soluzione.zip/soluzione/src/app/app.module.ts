import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar.component';
import { ProfiloComponent } from './components/profilo/profilo.component';
import { FilmComponent } from './components/film/film.component';
import { HttpClientModule } from '@angular/common/http';
import { AuthModule } from './auth/auth.module';
import { Route, RouterModule } from '@angular/router';
import { AuthGuard } from './auth/auth.guard';
import { FilmCardComponent } from './components/film-card/film-card.component';

const routes: Route[] = [
  {
    path: '',
    component: FilmComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'profilo',
    component: ProfiloComponent,
    canActivate: [AuthGuard]
  },
  {
    path: '**',
    redirectTo: ''
  }
]

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    ProfiloComponent,
    FilmComponent,
    FilmCardComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    AuthModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
