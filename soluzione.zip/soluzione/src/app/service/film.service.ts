import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Favoriti } from '../models/favoriti';
import { Film } from '../models/film';

@Injectable({
  providedIn: 'root'
})
export class FilmService {
  baseUrl = 'http://localhost:4201/api'

  constructor(private http: HttpClient) { }

  caricaFilm(){
    return this.http.get<Film[]>(`${this.baseUrl}/movie/popular`)
  }

  caricaPreferiti(id: number | undefined){
    return this.http.get<Favoriti[]>(`${this.baseUrl}/favorites?userId=${id}`)
  }

  aggiungiPreferito(movieId:number, userId: number){
    const favorite: Favoriti = { movieId, userId }
    return this.http.post<Favoriti>(`${this.baseUrl}/favorites`,favorite)

  }

  removeFavorites(id: number) {
    return this.http.delete<Favoriti>(`${this.baseUrl}/favorites/${id}`);
  }
}
